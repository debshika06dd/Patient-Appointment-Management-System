package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.model.Doctor;
import com.example.demo.repo.AppointmentRepository;
import com.example.demo.repo.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.example.demo.model.Patient;
import com.example.demo.model.Doctor;
import com.example.demo.repo.PatientRepository;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private NotificationEmailService notificationEmailService;

    public Appointment bookAppointment(Appointment appointment) {
        var existing = appointmentRepository.findByDoctorIdAndAppointmentDateAndTimeSlotAndStatus(
                appointment.getDoctorId(),
                appointment.getAppointmentDate(),
                appointment.getTimeSlot(),
                Appointment.AppointmentStatus.BOOKED
        );
        if (existing.isPresent()) {
            throw new RuntimeException("This time slot is already booked for this doctor.");
        }
        appointment.setStatus(Appointment.AppointmentStatus.BOOKED);
        Appointment saved = appointmentRepository.save(appointment);

        // Fetch patient and doctor details
        Patient patient = patientRepository.findById(saved.getPatientId()).orElse(null);
        Doctor doctor = doctorRepository.findById(saved.getDoctorId()).orElse(null);
        if (patient != null && doctor != null) {
            String patientEmail = patient.getEmail();
            String doctorName = doctor.getName();
            String doctorDegree = doctor.getSpecialization();
            String date = saved.getAppointmentDate().toString();
            String time = saved.getTimeSlot().toString();
            notificationEmailService.sendAppointmentNotification(
                patientEmail, doctorName, doctorDegree, date, time
            );
        }
        return saved;
    }

    public Appointment cancelAppointment(Integer appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        appointment.setStatus(Appointment.AppointmentStatus.CANCELED);
        return appointmentRepository.save(appointment);
    }

    public List<Appointment> getAppointmentsByPatient(Integer patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    public List<Appointment> getAppointmentsByDoctor(Integer doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    public List<LocalTime> getAvailableSlots(Integer doctorId, LocalDate date) {
        LocalTime startTime = LocalTime.of(9, 0);
        LocalTime endTime   = LocalTime.of(17, 0);

        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
        if (doctor != null) {
            if (doctor.getStartTime() != null) startTime = doctor.getStartTime();
            if (doctor.getEndTime()   != null) endTime   = doctor.getEndTime();
        }

        List<LocalTime> allSlots = new ArrayList<>();
        LocalTime temp = startTime;
        while (temp.isBefore(endTime)) {
            allSlots.add(temp);
            temp = temp.plusMinutes(30);
        }

        List<LocalTime> busyTimes = appointmentRepository
            .findByDoctorIdAndAppointmentDateAndStatus(doctorId, date, Appointment.AppointmentStatus.BOOKED)
            .stream()
            .map(Appointment::getTimeSlot)
            .collect(Collectors.toList());

        allSlots.removeAll(busyTimes);
        return allSlots;
    }
}