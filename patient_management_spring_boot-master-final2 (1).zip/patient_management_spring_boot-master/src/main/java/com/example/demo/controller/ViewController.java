package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {

    @GetMapping("/")
    public String home() { return "index"; }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/register")
    public String register() { return "register"; }

    @GetMapping("/dashboard")
    public String dashboard() { return "dashboard"; }

    @GetMapping("/doctors")
    public String doctors() { return "doctors"; }

    @GetMapping("/book")
    public String book() { return "book"; }

    @GetMapping("/appointments")
    public String appointments() { return "appointments"; }

    @GetMapping("/profile")
    public String profile() { return "profile"; }

    @GetMapping("/admin")
    public String admin() { return "admin"; }

    // ── Doctor portal ──
    @GetMapping("/doctor/login")
    public String doctorLogin() { return "doctor-login"; }

    @GetMapping("/doctor/dashboard")
    public String doctorDashboard() { return "doctor-dashboard"; }

    // ── Admin portal ──
    @GetMapping("/admin/login")
    public String adminLogin() { return "admin-login"; }
}
