package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.model.Patient;
import com.example.demo.repo.PatientRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {

    private final PatientRepository patientRepository;
   
    /* private final AppointmentRepository appointmentRepository;

    public PatientService(PatientRepository patientRepository, AppointmentRepository appointmentRepository) {
        this.patientRepository = patientRepository;
        this.appointmentRepository = appointmentRepository;
    } */
     
    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
        
    }
    
    public Patient registerPatient(Patient patient) {
        Optional<Patient> existingPatient = patientRepository.findByEmail(patient.getEmail());
        if (existingPatient.isPresent()) {
            throw new RuntimeException("Email " + patient.getEmail() + " is already registered.");
        }
        return patientRepository.save(patient);
    }

    public boolean loginPatient(String email, String password) {
        Optional<Patient> patient = patientRepository.findByEmail(email);
        if (patient.isPresent() ) {
            // In a production app, you would verify an encoded password here  now just check as it is....
        	
        	if (patient.get().getPassword().equals(password)) {
                return true; // Email found AND password matches
            }
           
        }
        return false;
    }

    public Patient getPatientByEmail(String email) {
        return patientRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Patient not found with email: " + email));
    }

    public Patient updatePatientProfile(Patient patient) {
        Patient existingPatient = patientRepository.findById(patient.getPatientId())
                .orElseThrow(() -> new RuntimeException("Patient with ID " + patient.getPatientId() + " not found."));
        
        existingPatient.setName(patient.getName());
        existingPatient.setPhone(patient.getPhone());
        existingPatient.setAddress(patient.getAddress());
        existingPatient.setDob(patient.getDob());
        
        return patientRepository.save(existingPatient);
    }

  /*  public List<Appointment> viewAppointmentHistory(Integer patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }  */
}