package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Patient;
import com.example.demo.service.PatientService;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerPatient(@RequestBody Patient patient) {
        try {
            Patient createdPatient = patientService.registerPatient(patient);
            return new ResponseEntity<>(createdPatient, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginPatient(@RequestParam String email, @RequestParam String password) {
        boolean success = patientService.loginPatient(email, password);
        if (success) {
            return ResponseEntity.ok("Login successful.");
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password.");
    }

    @GetMapping("/by-email")
    public ResponseEntity<?> getPatientByEmail(@RequestParam String email) {
        try {
            Patient patient = patientService.getPatientByEmail(email);
            return ResponseEntity.ok(patient);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updatePatientProfile(@RequestBody Patient patient) {
        try {
            Patient updated = patientService.updatePatientProfile(patient);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

   /* @GetMapping("/{patientId}/history")
    public ResponseEntity<List<Appointment>> viewAppointmentHistory(@PathVariable Integer patientId) {
        List<Appointment> history = patientService.viewAppointmentHistory(patientId);
        return ResponseEntity.ok(history);
    }  */
}