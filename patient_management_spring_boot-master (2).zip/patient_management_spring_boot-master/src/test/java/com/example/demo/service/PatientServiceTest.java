package com.example.demo.service;

import com.example.demo.model.Patient;
import com.example.demo.repo.PatientRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PatientServiceTest {

    @Mock
    private PatientRepository patientRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private PatientService patientService;

    @Test
    void registerPatient_shouldEncodePassword_andSavePatient() {
        Patient input = new Patient();
        input.setEmail("john@example.com");
        input.setPassword("plain123");
        input.setName("John");

        when(patientRepository.findByEmail("john@example.com")).thenReturn(Optional.empty());
        when(passwordEncoder.encode("plain123")).thenReturn("ENCODED_PASS");
        when(patientRepository.save(any(Patient.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Patient saved = patientService.registerPatient(input);

        assertNotNull(saved);
        assertEquals("ENCODED_PASS", saved.getPassword());

        ArgumentCaptor<Patient> captor = ArgumentCaptor.forClass(Patient.class);
        verify(patientRepository).save(captor.capture());
        assertEquals("ENCODED_PASS", captor.getValue().getPassword());
    }

    @Test
    void registerPatient_shouldThrow_whenEmailAlreadyRegistered() {
        Patient input = new Patient();
        input.setEmail("john@example.com");

        when(patientRepository.findByEmail("john@example.com")).thenReturn(Optional.of(new Patient()));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> patientService.registerPatient(input));
        assertTrue(ex.getMessage().contains("already registered"));
        verify(patientRepository, never()).save(any());
    }

    @Test
    void loginPatient_shouldReturnTrue_whenPasswordMatches() {
        Patient existing = new Patient();
        existing.setEmail("john@example.com");
        existing.setPassword("ENCODED_PASS");

        when(patientRepository.findByEmail("john@example.com")).thenReturn(Optional.of(existing));
        when(passwordEncoder.matches("plain123", "ENCODED_PASS")).thenReturn(true);

        boolean result = patientService.loginPatient("john@example.com", "plain123");

        assertTrue(result);
    }

    @Test
    void loginPatient_shouldReturnFalse_whenPatientNotFound() {
        when(patientRepository.findByEmail("missing@example.com")).thenReturn(Optional.empty());

        boolean result = patientService.loginPatient("missing@example.com", "plain123");

        assertFalse(result);
        verify(passwordEncoder, never()).matches(any(), any());
    }
}
