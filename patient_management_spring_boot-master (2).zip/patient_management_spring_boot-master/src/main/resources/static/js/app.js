/**
 * app.js – Shared utilities for Patient Management System
 * All REST calls target the Spring Boot backend on the same server.
 */

/* ──────────────────────────────────────────
   Constants
   ────────────────────────────────────────── */
const API = {
  PATIENTS:     '/api/patients',
  DOCTORS:      '/api/doctors',
  APPOINTMENTS: '/api/appointments',
};

/* ──────────────────────────────────────────
   Auth helpers  (localStorage)
   ────────────────────────────────────────── */
const Auth = {
  /** Save patient data after login */
  save(patient) {
    localStorage.setItem('pm_patient', JSON.stringify(patient));
  },
  /** Retrieve saved patient (or null) */
  get() {
    const raw = localStorage.getItem('pm_patient');
    return raw ? JSON.parse(raw) : null;
  },
  /** Clear session */
  clear() {
    localStorage.removeItem('pm_patient');
  },
  /** Returns true if a patient is logged in */
  isLoggedIn() {
    return !!this.get();
  },
  /** Redirect to login if not authenticated */
  requireLogin() {
    if (!this.isLoggedIn()) {
      window.location.href = '/login';
    }
  },
  /** Redirect to dashboard if already logged in */
  redirectIfLoggedIn() {
    if (this.isLoggedIn()) {
      window.location.href = '/dashboard';
    }
  },
};

/* ──────────────────────────────────────────
   DoctorAuth helpers  (localStorage)
   ────────────────────────────────────────── */
const DoctorAuth = {
  save(doctor) {
    localStorage.setItem('pm_doctor', JSON.stringify(doctor));
  },
  get() {
    const raw = localStorage.getItem('pm_doctor');
    return raw ? JSON.parse(raw) : null;
  },
  clear() {
    localStorage.removeItem('pm_doctor');
  },
  isLoggedIn() {
    return !!this.get();
  },
  requireLogin() {
    if (!this.isLoggedIn()) {
      window.location.href = '/doctor/login';
    }
  },
  redirectIfLoggedIn() {
    if (this.isLoggedIn()) {
      window.location.href = '/doctor/dashboard';
    }
  },
};

/* ──────────────────────────────────────────
   AdminAuth helpers  (localStorage)
   ────────────────────────────────────────── */
const AdminAuth = {
  save(admin)  { localStorage.setItem('pm_admin', JSON.stringify(admin)); },
  get()        { const r = localStorage.getItem('pm_admin'); return r ? JSON.parse(r) : null; },
  clear()      { localStorage.removeItem('pm_admin'); },
  isLoggedIn() { return !!this.get(); },
  requireLogin()       { if (!this.isLoggedIn()) window.location.href = '/admin/login'; },
  redirectIfLoggedIn() { if (this.isLoggedIn()) window.location.href = '/admin'; },
};

/* ──────────────────────────────────────────
   Toast notifications
   ────────────────────────────────────────── */
function showToast(message, type = 'info', duration = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const toast = document.createElement('div');
  toast.className = `toast-msg ${type}`;
  toast.innerHTML = `<span>${icons[type] || ''}</span> ${message}`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity .4s ease';
    setTimeout(() => toast.remove(), 400);
  }, duration);
}

/* ──────────────────────────────────────────
   Spinner
   ────────────────────────────────────────── */
function showSpinner() {
  if (document.getElementById('global-spinner')) return;
  const el = document.createElement('div');
  el.id = 'global-spinner';
  el.className = 'spinner-overlay';
  el.innerHTML = '<div class="spinner-ring"></div>';
  document.body.appendChild(el);
}

function hideSpinner() {
  const el = document.getElementById('global-spinner');
  if (el) el.remove();
}

/* ──────────────────────────────────────────
   API helpers
   ────────────────────────────────────────── */
async function apiFetch(url, options = {}) {
  const defaults = {
    headers: { 'Content-Type': 'application/json' },
  };
  const cfg = { ...defaults, ...options };
  if (cfg.body && typeof cfg.body === 'object') {
    cfg.body = JSON.stringify(cfg.body);
  }

  const res = await fetch(url, cfg);
  const contentType = res.headers.get('content-type') || '';

  let data;
  if (contentType.includes('application/json')) {
    data = await res.json();
  } else {
    data = await res.text();
  }

  if (!res.ok) {
    const msg = typeof data === 'string'
      ? data
      : (data.message || data.error || data.title || `Request failed (${res.status})`);
    throw new Error(msg);
  }
  return data;
}

/* ──────────────────────────────────────────
   Navbar: highlight active link & show/hide
   auth-dependent items
   ────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  // Hamburger menu toggle
  const hamburger = document.querySelector('.hamburger');
  const navLinks   = document.querySelector('.nav-links');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => navLinks.classList.toggle('open'));
  }

  // Highlight active nav link
  const currentPath = window.location.pathname;
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === currentPath) a.classList.add('active');
  });

  // Show / hide auth-aware nav items
  const patient = Auth.get();
  document.querySelectorAll('[data-auth="true"]').forEach(el => {
    el.style.display = patient ? '' : 'none';
  });
  document.querySelectorAll('[data-auth="false"]').forEach(el => {
    el.style.display = patient ? 'none' : '';
  });

  // Populate patient name placeholders
  if (patient) {
    document.querySelectorAll('.nav-patient-name').forEach(el => {
      el.textContent = patient.name ? patient.name.split(' ')[0] : 'Patient';
    });
  }
});

/* ──────────────────────────────────────────
   Logout
   ────────────────────────────────────────── */
async function logout() {
  try {
    await fetch('/logout', { method: 'POST', credentials: 'same-origin' });
  } catch (_) {}

  Auth.clear();
  showToast('You have been logged out.', 'info');
  setTimeout(() => window.location.replace('/login'), 500);
}

function enforceAuthOnPageRestore() {
  const path = window.location.pathname;
  const patientProtected = ['/dashboard', '/book', '/appointments', '/profile'];
  const doctorProtected = ['/doctor/dashboard'];
  const adminProtected = ['/admin'];

  if (patientProtected.includes(path) && !Auth.isLoggedIn()) {
    window.location.replace('/login');
    return;
  }
  if (doctorProtected.includes(path) && !DoctorAuth.isLoggedIn()) {
    window.location.replace('/doctor/login');
    return;
  }
  if (adminProtected.includes(path) && !AdminAuth.isLoggedIn()) {
    window.location.replace('/admin/login');
  }
}

window.addEventListener('pageshow', enforceAuthOnPageRestore);

/* ──────────────────────────────────────────
   Date / Time formatters
   ────────────────────────────────────────── */
function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatTime(timeStr) {
  if (!timeStr) return '—';
  const [h, m] = timeStr.split(':');
  const hour = parseInt(h, 10);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const h12  = hour % 12 || 12;
  return `${h12}:${m} ${ampm}`;
}

function getDayMonth(dateStr) {
  if (!dateStr) return { day: '—', month: '—' };
  const d = new Date(dateStr + 'T00:00:00');
  return {
    day:   d.getDate(),
    month: d.toLocaleDateString('en-US', { month: 'short' }),
  };
}

/* ──────────────────────────────────────────
   Minimum date helper  (today or later)
   ────────────────────────────────────────── */
function todayISO() {
  return new Date().toISOString().split('T')[0];
}
