package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.repo.AdminRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;
    


    /**
     * Seed a default admin on first startup if none exists.
     * Credentials: admin@medicare.com / admin123
     */
    @PostConstruct
    public void seedDefaultAdmin() {
        if (adminRepository.count() == 0) {
            Admin admin = new Admin();
            admin.setName("System Admin");
            admin.setEmail("admin@medicare.com");
            admin.setPassword("admin123"); 
            adminRepository.save(admin);
            System.out.println("[MediCare] Default admin created → admin@medicare.com / admin123");
        }
    }

    public Admin loginAdmin(String email, String password) {
        Admin admin = adminRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("No admin account found with this email."));
        
        if (!admin.getPassword().equals(password)) {
            throw new RuntimeException("Incorrect password.");
        }
        return admin;
    }
}
