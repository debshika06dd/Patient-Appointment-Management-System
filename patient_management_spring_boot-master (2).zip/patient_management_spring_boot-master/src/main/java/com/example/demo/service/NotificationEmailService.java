package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class NotificationEmailService {
    @Autowired
    private JavaMailSender mailSender;

    public void sendAppointmentNotification(String to, String doctorName, String doctorDegree, String date, String time) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("riteshkolhe3031@gmail.com");
        message.setTo(to);
        message.setSubject("Appointment Confirmation");
        message.setText("Dear Patient,\n\nYour appointment with Dr. " + doctorName + " (" + doctorDegree + ") is confirmed for " + date + " at " + time + ".\n\nThank you for using our service!\n");
        mailSender.send(message);
    }
}
