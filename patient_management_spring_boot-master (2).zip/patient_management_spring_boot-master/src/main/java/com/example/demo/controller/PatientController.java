package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;

import com.example.demo.model.Patient;
import com.example.demo.service.PatientService;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerPatient(@RequestBody Patient patient) {
        try {
            Patient createdPatient = patientService.registerPatient(patient);
            return new ResponseEntity<>(sanitizePatient(createdPatient), HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginPatient(@RequestParam String email,
                                               @RequestParam String password,
                                               HttpServletRequest request) {
        boolean success = patientService.loginPatient(email, password);
        if (success) {
            Authentication authentication = new UsernamePasswordAuthenticationToken(
                    email,
                    null,
                    List.of(new SimpleGrantedAuthority("ROLE_PATIENT"))
            );

            SecurityContext context = SecurityContextHolder.createEmptyContext();
            context.setAuthentication(authentication);
            SecurityContextHolder.setContext(context);
            request.getSession(true).setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, context);

            return ResponseEntity.ok("Login successful.");
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password.");
    }

    @GetMapping("/by-email")
    public ResponseEntity<?> getPatientByEmail(@RequestParam String email) {
        try {
            Patient patient = patientService.getPatientByEmail(email);
            return ResponseEntity.ok(sanitizePatient(patient));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updatePatientProfile(@RequestBody Patient patient) {
        try {
            Patient updated = patientService.updatePatientProfile(patient);
            return ResponseEntity.ok(sanitizePatient(updated));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    private Patient sanitizePatient(Patient patient) {
        Patient safe = new Patient();
        safe.setPatientId(patient.getPatientId());
        safe.setName(patient.getName());
        safe.setEmail(patient.getEmail());
        safe.setRole(patient.getRole());
        safe.setPhone(patient.getPhone());
        safe.setAddress(patient.getAddress());
        safe.setDob(patient.getDob());
        return safe;
    }

   /* @GetMapping("/{patientId}/history")
    public ResponseEntity<List<Appointment>> viewAppointmentHistory(@PathVariable Integer patientId) {
        List<Appointment> history = patientService.viewAppointmentHistory(patientId);
        return ResponseEntity.ok(history);
    }  */
}