package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final NoCacheInterceptor noCacheInterceptor;

    @Autowired
    public WebMvcConfig(NoCacheInterceptor noCacheInterceptor) {
        this.noCacheInterceptor = noCacheInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(noCacheInterceptor)
                .addPathPatterns(
                        "/dashboard",
                        "/book",
                        "/appointments",
                        "/profile",
                        "/doctor/dashboard",
                        "/admin",
                        "/api/patients/by-email",
                        "/api/patients/profile",
                        "/api/appointments/**",
                        "/api/doctors/add"
                );
    }
}
