package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "Appointment")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer appointmentId; // [cite: 70, 133]

    @Column(name = "patientId")
    private Integer patientId; // [cite: 71, 134]

    @Column(name = "doctorId")
    private Integer doctorId; // [cite: 72, 135]

    private LocalDate appointmentDate; // [cite: 73, 136]
    private LocalTime timeSlot; // [cite: 74, 137]

    @Enumerated(EnumType.STRING)
    private AppointmentStatus status; // [cite: 75, 138]

    public enum AppointmentStatus {
        BOOKED, CANCELED, COMPLETED
    }

    // Getters and Setters
    public Integer getAppointmentId() { return appointmentId; }
    public void setAppointmentId(Integer appointmentId) { this.appointmentId = appointmentId; }
    public Integer getPatientId() { return patientId; }
    public void setPatientId(Integer patientId) { this.patientId = patientId; }
    public Integer getDoctorId() { return doctorId; }
    public void setDoctorId(Integer doctorId) { this.doctorId = doctorId; }
    public LocalDate getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(LocalDate appointmentDate) { this.appointmentDate = appointmentDate; }
    public LocalTime getTimeSlot() { return timeSlot; }
    public void setTimeSlot(LocalTime timeSlot) { this.timeSlot = timeSlot; }
    public AppointmentStatus getStatus() { return status; }
    public void setStatus(AppointmentStatus status) { this.status = status; }
}