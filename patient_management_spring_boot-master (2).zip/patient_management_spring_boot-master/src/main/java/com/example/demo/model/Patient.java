package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "Patient")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer patientId; // [cite: 29, 115]

    @Column(length = 100)
    private String name; // [cite: 30, 116]

    @Column(length = 100, unique = true, nullable = false)
    private String email; // [cite: 31, 117]

    @Column(nullable = false)
    private String password; // Added for loginPatient() [cite: 18]

    private String role = "PATIENT"; // Added for system roles [cite: 8]

    @Column(length = 15)
    private String phone; // [cite: 32, 118]

    @Column(columnDefinition = "TEXT")
    private String address; // [cite: 33, 119]

    private LocalDate dob; // [cite: 34, 120]

    // Constructors
    public Patient() {}

    // Getters and Setters
    public Integer getPatientId() { return patientId; }
    public void setPatientId(Integer patientId) { this.patientId = patientId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }
}