package com.example.demo.repo;

import com.example.demo.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
    
    // Check if a doctor is already booked at a specific time
    Optional<Appointment> findByDoctorIdAndAppointmentDateAndTimeSlotAndStatus(
            Integer doctorId, LocalDate date, LocalTime time, Appointment.AppointmentStatus status);

    // View appointment history for a specific patient
    List<Appointment> findByPatientId(Integer patientId);

    // Get all appointments for a specific doctor
    List<Appointment> findByDoctorId(Integer doctorId);

    // Used to calculate available slots for a doctor on a date
    List<Appointment> findByDoctorIdAndAppointmentDateAndStatus(
        Integer doctorId, LocalDate date, Appointment.AppointmentStatus status);
}