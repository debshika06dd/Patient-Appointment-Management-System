package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(
                                "/",
                                "/error",
                                "/login",
                                "/login/**",
                                "/register",
                                "/register/**",
                                "/doctor/login",
                                "/doctor/login/**",
                                "/admin/login",
                                "/admin/login/**",
                                "/css/**",
                                "/js/**",
                                "/images/**",
                                "/doctors",
                                "/api/patients/register",
                                "/api/patients/login",
                                "/api/doctors/all",
                                "/api/doctors/login",
                                "/api/admin/login"
                        ).permitAll()
                        .requestMatchers("/dashboard", "/book", "/appointments", "/profile").hasRole("PATIENT")
                        .requestMatchers("/doctor/dashboard").hasRole("DOCTOR")
                        .requestMatchers("/admin").hasRole("ADMIN")
                        .requestMatchers("/api/patients/by-email", "/api/patients/profile").hasRole("PATIENT")
                        .requestMatchers("/api/appointments/book", "/api/appointments/patient/**", "/api/appointments/cancel/**", "/api/appointments/available-slots").hasRole("PATIENT")
                        .requestMatchers("/api/appointments/doctor/**").hasAnyRole("DOCTOR", "ADMIN")
                        .requestMatchers("/api/doctors/add").hasRole("ADMIN")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .deleteCookies("JSESSIONID")
                )
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                        .invalidSessionUrl("/login")
                )
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint((request, response, authException) -> {
                                                        String uri = request.getRequestURI();
                                                        if (uri.startsWith("/api/")) {
                                response.sendError(401, "Unauthorized");
                                                        } else if (uri.startsWith("/doctor/")) {
                                                                response.sendRedirect("/doctor/login");
                                                        } else if (uri.startsWith("/admin")) {
                                                                response.sendRedirect("/admin/login");
                            } else {
                                response.sendRedirect("/login");
                            }
                                                })
                                                .accessDeniedHandler((request, response, accessDeniedException) -> {
                                                        String uri = request.getRequestURI();
                                                        if (uri.startsWith("/api/")) {
                                                                response.sendError(403, "Forbidden");
                                                        } else if (uri.startsWith("/doctor/")) {
                                                                response.sendRedirect("/doctor/login");
                                                        } else if (uri.startsWith("/admin")) {
                                                                response.sendRedirect("/admin/login");
                                                        } else {
                                                                response.sendRedirect("/login");
                                                        }
                        })
                );

        return http.build();
    }
}
