package com.example.demo.controller;

import com.example.demo.model.Appointment;
import com.example.demo.model.Doctor;
import com.example.demo.repo.DoctorRepository;
import com.example.demo.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private DoctorRepository doctorRepository;

    // Book a new appointment
    @PostMapping("/book")
    public ResponseEntity<?> bookAppointment(@RequestBody Appointment appointment) {
        try {
            Appointment booked = appointmentService.bookAppointment(appointment);
            return ResponseEntity.ok(booked);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Cancel an appointment
    @PutMapping("/cancel/{id}")
    public ResponseEntity<Appointment> cancelAppointment(@PathVariable Integer id) {
        return ResponseEntity.ok(appointmentService.cancelAppointment(id));
    }

    // Doctor cancels own appointment
    @PutMapping("/doctor/cancel/{id}")
    public ResponseEntity<?> cancelAppointmentByDoctor(@PathVariable Integer id, Authentication authentication) {
        try {
            Doctor doctor = doctorRepository.findByEmail(authentication.getName())
                    .orElseThrow(() -> new RuntimeException("Doctor not found."));
            return ResponseEntity.ok(appointmentService.cancelAppointmentByDoctor(id, doctor.getDoctorId()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // View all appointments for a patient
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<Appointment>> viewAppointments(@PathVariable Integer patientId) {
        return ResponseEntity.ok(appointmentService.getAppointmentsByPatient(patientId));
    }

    // View all appointments for a doctor (doctor dashboard)
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<Appointment>> viewDoctorAppointments(@PathVariable Integer doctorId) {
        return ResponseEntity.ok(appointmentService.getAppointmentsByDoctor(doctorId));
    }

    // Doctor marks own appointment as completed
    @PutMapping("/doctor/complete/{id}")
    public ResponseEntity<?> completeAppointmentByDoctor(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(appointmentService.completeAppointment(id));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Get available time slots for a doctor on a date
    @GetMapping("/available-slots")
    public List<LocalTime> getSlots(@RequestParam Integer doctorId, @RequestParam String date) {
        return appointmentService.getAvailableSlots(doctorId, LocalDate.parse(date));
    }
}