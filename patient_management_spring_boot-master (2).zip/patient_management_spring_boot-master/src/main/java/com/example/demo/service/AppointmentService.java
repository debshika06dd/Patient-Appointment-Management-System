package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.model.Doctor;
import com.example.demo.repo.AppointmentRepository;
import com.example.demo.repo.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.example.demo.model.Patient;
import com.example.demo.repo.PatientRepository;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private NotificationEmailService notificationEmailService;

    public Appointment bookAppointment(Appointment appointment) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime slotDateTime = LocalDateTime.of(appointment.getAppointmentDate(), appointment.getTimeSlot());

        if (appointment.getAppointmentDate().isBefore(now.toLocalDate())) {
            throw new RuntimeException("Selected appointment date has already passed.");
        }

        if (appointment.getAppointmentDate().isEqual(now.toLocalDate())) {
            LocalDateTime nextBoundary = getNextHalfHourBoundary(now);
            if (slotDateTime.isBefore(nextBoundary)) {
                throw new RuntimeException("Selected slot time has already passed.");
            }
        } else if (slotDateTime.isBefore(now)) {
            throw new RuntimeException("Selected slot time has already passed.");
        }

        var existing = appointmentRepository.findByDoctorIdAndAppointmentDateAndTimeSlotAndStatus(
                appointment.getDoctorId(),
                appointment.getAppointmentDate(),
                appointment.getTimeSlot(),
                Appointment.AppointmentStatus.BOOKED
        );
        if (existing.isPresent()) {
            throw new RuntimeException("This time slot is already booked for this doctor.");
        }
        appointment.setStatus(Appointment.AppointmentStatus.BOOKED);
        Appointment saved = appointmentRepository.save(appointment);

        // Fetch patient and doctor details
        Patient patient = patientRepository.findById(saved.getPatientId()).orElse(null);
        Doctor doctor = doctorRepository.findById(saved.getDoctorId()).orElse(null);
        if (patient != null && doctor != null) {
            String patientEmail = patient.getEmail();
            String doctorName = doctor.getName();
            String doctorDegree = doctor.getSpecialization();
            String date = saved.getAppointmentDate().toString();
            String time = saved.getTimeSlot().toString();
            notificationEmailService.sendAppointmentNotification(
                patientEmail, doctorName, doctorDegree, date, time
            );
        }
        return saved;
    }

    public Appointment cancelAppointment(Integer appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        appointment.setStatus(Appointment.AppointmentStatus.CANCELED);
        return appointmentRepository.save(appointment);
    }

    public Appointment cancelAppointmentByDoctor(Integer appointmentId, Integer doctorId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        if (!appointment.getDoctorId().equals(doctorId)) {
            throw new RuntimeException("You can cancel only your own appointments.");
        }

        appointment.setStatus(Appointment.AppointmentStatus.CANCELED);
        return appointmentRepository.save(appointment);
    }

    public Appointment completeAppointment(Integer appointmentId, Integer doctorId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        if (!appointment.getDoctorId().equals(doctorId)) {
            throw new RuntimeException("You can complete only your own appointments.");
        }
        if (appointment.getStatus() == Appointment.AppointmentStatus.CANCELED) {
            throw new RuntimeException("Appointment was cancelled.");
        }

        appointment.setStatus(Appointment.AppointmentStatus.COMPLETED);
        return appointmentRepository.save(appointment);
    }

    public Appointment completeAppointment(Integer appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        if (appointment.getStatus() == Appointment.AppointmentStatus.CANCELED) {
            throw new RuntimeException("Appointment was cancelled.");
        }

        appointment.setStatus(Appointment.AppointmentStatus.COMPLETED);
        return appointmentRepository.save(appointment);
    }

    public List<Appointment> getAppointmentsByPatient(Integer patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    public List<Appointment> getAppointmentsByDoctor(Integer doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    public List<LocalTime> getAvailableSlots(Integer doctorId, LocalDate date) {
        if (date.isBefore(LocalDate.now())) {
            return List.of();
        }

        LocalTime startTime = LocalTime.of(9, 0);
        LocalTime endTime   = LocalTime.of(17, 0);

        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
        if (doctor != null) {
            if (doctor.getStartTime() != null) startTime = doctor.getStartTime();
            if (doctor.getEndTime()   != null) endTime   = doctor.getEndTime();
        }

        List<LocalTime> allSlots = new ArrayList<>();
        LocalTime temp = startTime;
        while (temp.isBefore(endTime)) {
            allSlots.add(temp);
            temp = temp.plusMinutes(30);
        }

        List<LocalTime> busyTimes = appointmentRepository
            .findByDoctorIdAndAppointmentDateAndStatus(doctorId, date, Appointment.AppointmentStatus.BOOKED)
            .stream()
            .map(Appointment::getTimeSlot)
            .collect(Collectors.toList());

        allSlots.removeAll(busyTimes);

        if (date.equals(LocalDate.now())) {
            LocalTime now = getNextHalfHourBoundary(LocalDateTime.now()).toLocalTime();
            allSlots = allSlots.stream()
                    .filter(slot -> !slot.isBefore(now))
                    .collect(Collectors.toList());
        }

        return allSlots;
    }

    private LocalDateTime getNextHalfHourBoundary(LocalDateTime dateTime) {
        LocalDateTime base = dateTime.withSecond(0).withNano(0);
        int minute = base.getMinute();

        if (minute == 0 || minute == 30) {
            return base.plusMinutes(30);
        }

        if (minute < 30) {
            return base.withMinute(30);
        }

        return base.plusHours(1).withMinute(0);
    }
}