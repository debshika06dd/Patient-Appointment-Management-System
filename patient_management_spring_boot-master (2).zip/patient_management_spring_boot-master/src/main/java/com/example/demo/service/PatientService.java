package com.example.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.demo.model.Patient;
import com.example.demo.repo.PatientRepository;

//import java.util.List;
import java.util.Optional;

@Service
public class PatientService {

    private final PatientRepository patientRepository;
    private final PasswordEncoder passwordEncoder;
    
    
   
    /* private final AppointmentRepository appointmentRepository;

    public PatientService(PatientRepository patientRepository, AppointmentRepository appointmentRepository) {
        this.patientRepository = patientRepository;
        this.appointmentRepository = appointmentRepository;
    } */
     
    public PatientService(PatientRepository patientRepository, PasswordEncoder passwordEncoder) {
        this.patientRepository = patientRepository;
        this.passwordEncoder = passwordEncoder;
    }
    
    public Patient registerPatient(Patient patient) {
        Optional<Patient> existingPatient = patientRepository.findByEmail(patient.getEmail());
        if (existingPatient.isPresent()) {
            throw new RuntimeException("Email " + patient.getEmail() + " is already registered.");
        }
        patient.setPassword(passwordEncoder.encode(patient.getPassword()));
        return patientRepository.save(patient);
    }

    public boolean loginPatient(String email, String password) {
        Optional<Patient> patient = patientRepository.findByEmail(email);
        if (patient.isPresent()) {
            return passwordEncoder.matches(password, patient.get().getPassword());
        }
        return false;
    }

    public Patient getPatientByEmail(String email) {
        return patientRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Patient not found with email: " + email));
    }

    public Patient updatePatientProfile(Patient patient) {
        Patient existingPatient = patientRepository.findById(patient.getPatientId())
                .orElseThrow(() -> new RuntimeException("Patient with ID " + patient.getPatientId() + " not found."));
        
        existingPatient.setName(patient.getName());
        existingPatient.setPhone(patient.getPhone());
        existingPatient.setAddress(patient.getAddress());
        existingPatient.setDob(patient.getDob());
        if (patient.getPassword() != null && !patient.getPassword().isBlank()) {
            existingPatient.setPassword(passwordEncoder.encode(patient.getPassword()));
        }
        
        
        return patientRepository.save(existingPatient);
    }

  /*  public List<Appointment> viewAppointmentHistory(Integer patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }  */
}